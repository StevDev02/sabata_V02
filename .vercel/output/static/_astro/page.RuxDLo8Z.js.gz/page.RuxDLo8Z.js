import{i}from"./index.D6rU_tt3.js";i();
