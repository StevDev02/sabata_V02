import{i}from"./index.CZNXKH1e.js";i();
