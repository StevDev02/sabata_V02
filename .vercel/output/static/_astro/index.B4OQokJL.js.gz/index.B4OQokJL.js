import{r as t}from"./index.CWrl8SxZ.js";const o=t.createContext(void 0);function a(e){const r=t.useContext(o);return e||r||"ltr"}export{a as $};
